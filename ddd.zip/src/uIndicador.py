#!/usr/local/bin/python
from tkinter import *

class Registrador(Frame):
    def __init__(self, master=None):
        super().__init__(master)
        pass